<?php
class OctoBookings {

    private $auth;
    private $hold_minutes = 30;

    public function __construct(OctoAuth $auth) {
        $this->auth = $auth;
    }

    public function register_routes() {
        // Crear booking (ON_HOLD)
        register_rest_route('octo/v1', '/bookings', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'create_booking'),
            'permission_callback' => '__return_true',
        ));

        // Listar bookings
        register_rest_route('octo/v1', '/bookings', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'list_bookings'),
            'permission_callback' => '__return_true',
        ));

        // Obtener booking
        register_rest_route('octo/v1', '/bookings/(?P<uuid>[a-zA-Z0-9\-]+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_booking'),
            'permission_callback' => '__return_true',
        ));

        // Confirmar booking
        register_rest_route('octo/v1', '/bookings/(?P<uuid>[a-zA-Z0-9\-]+)/confirm', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'confirm_booking'),
            'permission_callback' => '__return_true',
        ));

        // Cancelar booking
        register_rest_route('octo/v1', '/bookings/(?P<uuid>[a-zA-Z0-9\-]+)/cancel', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'cancel_booking'),
            'permission_callback' => '__return_true',
        ));

        // Extender hold
        register_rest_route('octo/v1', '/bookings/(?P<uuid>[a-zA-Z0-9\-]+)/extend', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'extend_booking'),
            'permission_callback' => '__return_true',
        ));
    }

    // =====================
    // CREAR BOOKING (ON_HOLD)
    // =====================
    public function create_booking(WP_REST_Request $request) {
        $auth = $this->auth->validate_request($request);
        if (is_wp_error($auth)) {
            return $this->auth->error_response(
                $auth->get_error_code(),
                $auth->get_error_message(),
                $auth->get_error_data()['status']
            );
        }

        $body = $request->get_json_params();

        if (empty($body['productId']) || empty($body['optionId']) || empty($body['availabilityId'])) {
            return $this->auth->error_response('ErrorBadRequest', 'Se requiere productId, optionId, availabilityId', 400);
        }

        if (empty($body['unitItems']) || !is_array($body['unitItems'])) {
            return $this->auth->error_response('ErrorBadRequest', 'Se requiere unitItems', 400);
        }

        // UUID: usar el del reseller si lo manda, si no generar uno
        $uuid = !empty($body['uuid']) ? sanitize_text_field($body['uuid']) : $this->generate_uuid();

        global $wpdb;
        $table_octo      = $wpdb->prefix . 'octo_bookings';
        $table_servicios = $wpdb->prefix . 'reservas_servicios';

        // Verificar idempotencia: si ya existe este UUID devolver el booking existente
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));
        if ($existing) {
            return new WP_REST_Response($this->format_booking($existing), 200);
        }

        // Extraer servicio_id del availabilityId
        $servicio_id = $this->decode_availability_id($body['availabilityId']);
        if (!$servicio_id) {
            return $this->auth->error_response('ErrorInvalidAvailabilityID', 'availabilityId no v��lido', 400);
        }

        // Obtener servicio con bloqueo
        $wpdb->query('START TRANSACTION');

        $servicio = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_servicios WHERE id = %d AND status = 'active' AND enabled = 1 FOR UPDATE",
            $servicio_id
        ));

        if (!$servicio) {
            $wpdb->query('ROLLBACK');
            return $this->auth->error_response('ErrorInvalidAvailabilityID', 'Servicio no encontrado', 404);
        }

        // Verificar que no ha pasado
        $fecha_hora_servicio = $servicio->fecha . ' ' . $servicio->hora;
        if (strtotime($fecha_hora_servicio) <= time()) {
            $wpdb->query('ROLLBACK');
            return $this->auth->error_response('ErrorBadRequest', 'Este servicio ya ha pasado', 400);
        }

        // Contar plazas necesarias (infants no ocupan plaza)
        $unit_items     = $body['unitItems'];
        $plazas_needed  = 0;
        $adultos        = 0;
        $ninos          = 0;
        $infants        = 0;
        $residentes     = 0;

        foreach ($unit_items as $item) {
            switch ($item['unitId'] ?? '') {
                case 'adult':    $adultos++;   $plazas_needed++; break;
                case 'child':    $ninos++;     $plazas_needed++; break;
                case 'resident': $residentes++; $plazas_needed++; break;
                case 'infant':   $infants++; break;
            }
        }

        if ($plazas_needed === 0) {
            $wpdb->query('ROLLBACK');
            return $this->auth->error_response('ErrorBadRequest', 'Debe haber al menos una persona con plaza', 400);
        }

        if (intval($servicio->plazas_disponibles) < $plazas_needed) {
            $wpdb->query('ROLLBACK');
            return $this->auth->error_response(
                'ErrorBadRequest',
                'Solo quedan ' . $servicio->plazas_disponibles . ' plazas. Solicitadas: ' . $plazas_needed,
                409
            );
        }

        // Restar plazas
        $wpdb->query($wpdb->prepare(
            "UPDATE $table_servicios SET plazas_disponibles = plazas_disponibles - %d WHERE id = %d",
            $plazas_needed, $servicio_id
        ));

        // Construir unit_items con UUIDs propios
        $unit_items_full = array();
        foreach ($unit_items as $item) {
            $unit_items_full[] = array(
                'uuid'   => $this->generate_uuid(),
                'unitId' => $item['unitId'],
                'unit'   => array('id' => $item['unitId']),
                'status' => 'ON_HOLD',
                'contact' => $item['contact'] ?? null,
                'ticket'  => null,
            );
        }

        // Timestamps
        $utc_now     = gmdate('Y-m-d H:i:s');
        $utc_expires = gmdate('Y-m-d H:i:s', time() + ($this->hold_minutes * 60));

        // Insertar en tabla OCTO
        $wpdb->insert($table_octo, array(
            'uuid'              => $uuid,
            'availability_id'   => $body['availabilityId'],
            'servicio_id'       => $servicio_id,
            'product_id'        => $body['productId'],
            'option_id'         => $body['optionId'],
            'status'            => 'ON_HOLD',
            'reseller_reference' => $body['resellerReference'] ?? null,
            'unit_items'        => json_encode($unit_items_full),
            'contact'           => json_encode($body['contact'] ?? array()),
            'utc_created_at'    => $utc_now,
            'utc_expires_at'    => $utc_expires,
            'test_mode'         => $auth['test_mode'] ? 1 : 0,
        ));
        
        if ($wpdb->last_error) {
            $wpdb->query('ROLLBACK');
            error_log('OCTO INSERT ERROR: ' . $wpdb->last_error);
            return $this->auth->error_response('ErrorInternalServerError', 'DB Error: ' . $wpdb->last_error, 500);
        }

        $wpdb->query('COMMIT');

        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));

        error_log("OCTO: Hold creado - UUID: {$uuid}, Servicio: {$servicio_id}, Plazas: {$plazas_needed}");

        return new WP_REST_Response($this->format_booking($booking, $servicio), 201);
    }

    // =====================
    // CONFIRMAR BOOKING
    // =====================
    public function confirm_booking(WP_REST_Request $request) {
        $auth = $this->auth->validate_request($request);
        if (is_wp_error($auth)) {
            return $this->auth->error_response(
                $auth->get_error_code(),
                $auth->get_error_message(),
                $auth->get_error_data()['status']
            );
        }

        $uuid = $request['uuid'];
        global $wpdb;
        $table_octo      = $wpdb->prefix . 'octo_bookings';
        $table_reservas  = $wpdb->prefix . 'reservas_reservas';
        $table_servicios = $wpdb->prefix . 'reservas_servicios';

        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));

        if (!$booking) {
            return $this->auth->error_response('ErrorBadRequest', 'Booking no encontrado', 404);
        }

        if ($booking->status === 'CONFIRMED') {
            $servicio = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_servicios WHERE id = %d", $booking->servicio_id
            ));
            return new WP_REST_Response($this->format_booking($booking, $servicio), 200);
        }

        if ($booking->status === 'EXPIRED') {
            return $this->auth->error_response('ErrorBadRequest', 'El hold ha expirado', 409);
        }

        if ($booking->status === 'CANCELLED') {
            return $this->auth->error_response('ErrorBadRequest', 'El booking est�� cancelado', 409);
        }

        // Obtener datos del servicio
        $servicio = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_servicios WHERE id = %d", $booking->servicio_id
        ));

        // Datos del contacto principal
        $contact     = json_decode($booking->contact, true) ?? array();
        $unit_items  = json_decode($booking->unit_items, true) ?? array();

        $adultos    = 0;
        $ninos      = 0;
        $infants    = 0;
        $residentes = 0;

        foreach ($unit_items as $item) {
            switch ($item['unitId']) {
                case 'adult':    $adultos++;    break;
                case 'child':    $ninos++;      break;
                case 'infant':   $infants++;    break;
                case 'resident': $residentes++; break;
            }
        }

        $total_personas = $adultos + $ninos + $residentes;

        // Calcular precio
        $precio_base = 0;
        if ($servicio) {
            $precio_base += $adultos    * floatval($servicio->precio_adulto);
            $precio_base += $ninos      * floatval($servicio->precio_nino);
            $precio_base += $residentes * floatval($servicio->precio_residente);
        }

        // Generar localizador
        $localizador = $this->generate_localizador();

        $body = $request->get_json_params() ?? array();

        // Crear reserva en sistema interno
        $reserva_data = array(
            'localizador'    => $localizador,
            'servicio_id'    => $booking->servicio_id,
            'fecha'          => $servicio ? $servicio->fecha : '',
            'hora'           => $servicio ? $servicio->hora  : '',
            'hora_vuelta'    => $servicio ? $servicio->hora_vuelta : null,
            'nombre'         => sanitize_text_field($contact['firstName'] ?? $body['contact']['firstName'] ?? 'OCTO'),
            'apellidos'      => sanitize_text_field($contact['lastName']  ?? $body['contact']['lastName']  ?? 'Booking'),
            'email'          => sanitize_email($contact['emailAddress']   ?? $body['contact']['emailAddress'] ?? ''),
            'telefono'       => sanitize_text_field($contact['phoneNumber'] ?? $body['contact']['phoneNumber'] ?? ''),
            'adultos'        => $adultos,
            'residentes'     => $residentes,
            'ninos_5_12'     => $ninos,
            'ninos_menores'  => $infants,
            'total_personas' => $total_personas,
            'precio_base'    => $precio_base,
            'descuento_total' => 0,
            'precio_final'   => $precio_base,
            'estado'         => 'confirmada',
            'metodo_pago'    => 'civitatis_octo',
            'created_at'     => current_time('mysql'),
        );

        $wpdb->insert($table_reservas, $reserva_data);
        $reserva_id = $wpdb->insert_id;

        // Actualizar unit_items con tickets QR
        $unit_items_confirmed = array();
        foreach ($unit_items as $item) {
            $item['status'] = 'CONFIRMED';
            $item['ticket'] = array(
                'redemptionMethod' => 'DIGITAL',
                'utcRedeemedAt'    => null,
                'deliveryOptions'  => array(
                    array(
                        'deliveryFormat' => 'QRCODE',
                        'deliveryValue'  => $localizador . '-' . $item['uuid'],
                    ),
                ),
            );
            $unit_items_confirmed[] = $item;
        }

        // Actualizar OCTO booking
        $utc_confirmed = gmdate('Y-m-d H:i:s');
        $wpdb->update($table_octo, array(
            'status'            => 'CONFIRMED',
            'supplier_reference' => $localizador,
            'reserva_id'        => $reserva_id,
            'unit_items'        => json_encode($unit_items_confirmed),
            'utc_confirmed_at'  => $utc_confirmed,
        ), array('uuid' => $uuid));

        $booking_updated = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));

        error_log("OCTO: Booking confirmado - UUID: {$uuid}, Localizador: {$localizador}");

        return new WP_REST_Response($this->format_booking($booking_updated, $servicio), 200);
    }

    // =====================
    // CANCELAR BOOKING
    // =====================
    public function cancel_booking(WP_REST_Request $request) {
        $auth = $this->auth->validate_request($request);
        if (is_wp_error($auth)) {
            return $this->auth->error_response(
                $auth->get_error_code(),
                $auth->get_error_message(),
                $auth->get_error_data()['status']
            );
        }

        $uuid = $request['uuid'];
        global $wpdb;
        $table_octo      = $wpdb->prefix . 'octo_bookings';
        $table_reservas  = $wpdb->prefix . 'reservas_reservas';
        $table_servicios = $wpdb->prefix . 'reservas_servicios';

        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));

        if (!$booking) {
            return $this->auth->error_response('ErrorBadRequest', 'Booking no encontrado', 404);
        }

        if ($booking->status === 'CANCELLED') {
            $servicio = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_servicios WHERE id = %d", $booking->servicio_id
            ));
            return new WP_REST_Response($this->format_booking($booking, $servicio), 200);
        }

        // Devolver plazas si no estaba ya expirado
        if (in_array($booking->status, array('ON_HOLD', 'CONFIRMED'))) {
            $unit_items  = json_decode($booking->unit_items, true) ?? array();
            $plazas      = 0;
            foreach ($unit_items as $item) {
                if ($item['unitId'] !== 'infant') $plazas++;
            }

            if ($plazas > 0) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE $table_servicios SET plazas_disponibles = plazas_disponibles + %d WHERE id = %d",
                    $plazas, $booking->servicio_id
                ));
            }

            // Cancelar reserva interna si existe
            if ($booking->reserva_id) {
                $wpdb->update($table_reservas, array(
                    'estado'             => 'cancelada',
                    'motivo_cancelacion' => 'Cancelaci��n via OCTO - ' . ($request->get_json_params()['reason'] ?? 'Sin motivo'),
                    'fecha_cancelacion'  => current_time('mysql'),
                ), array('id' => $booking->reserva_id));
            }
        }

        $wpdb->update($table_octo, array(
            'status'          => 'CANCELLED',
            'utc_cancelled_at' => gmdate('Y-m-d H:i:s'),
        ), array('uuid' => $uuid));

        $booking_updated = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));

        $servicio = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_servicios WHERE id = %d", $booking->servicio_id
        ));

        error_log("OCTO: Booking cancelado - UUID: {$uuid}");

        return new WP_REST_Response($this->format_booking($booking_updated, $servicio), 200);
    }

    // =====================
    // EXTENDER HOLD
    // =====================
    public function extend_booking(WP_REST_Request $request) {
        $auth = $this->auth->validate_request($request);
        if (is_wp_error($auth)) {
            return $this->auth->error_response(
                $auth->get_error_code(),
                $auth->get_error_message(),
                $auth->get_error_data()['status']
            );
        }

        $uuid = $request['uuid'];
        global $wpdb;
        $table_octo = $wpdb->prefix . 'octo_bookings';

        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));

        if (!$booking || $booking->status !== 'ON_HOLD') {
            return $this->auth->error_response('ErrorBadRequest', 'Booking no encontrado o no est�� en ON_HOLD', 400);
        }

        $new_expires = gmdate('Y-m-d H:i:s', time() + ($this->hold_minutes * 60));

        $wpdb->update($table_octo, array(
            'utc_expires_at' => $new_expires,
        ), array('uuid' => $uuid));

        $booking_updated = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));

        return new WP_REST_Response($this->format_booking($booking_updated), 200);
    }

    // =====================
    // OBTENER BOOKING
    // =====================
    public function get_booking(WP_REST_Request $request) {
        $auth = $this->auth->validate_request($request);
        if (is_wp_error($auth)) {
            return $this->auth->error_response(
                $auth->get_error_code(),
                $auth->get_error_message(),
                $auth->get_error_data()['status']
            );
        }

        $uuid = $request['uuid'];
        global $wpdb;
        $table_octo      = $wpdb->prefix . 'octo_bookings';
        $table_servicios = $wpdb->prefix . 'reservas_servicios';

        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_octo WHERE uuid = %s", $uuid
        ));

        if (!$booking) {
            return $this->auth->error_response('ErrorBadRequest', 'Booking no encontrado', 404);
        }

        $servicio = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_servicios WHERE id = %d", $booking->servicio_id
        ));

        return new WP_REST_Response($this->format_booking($booking, $servicio), 200);
    }

    // =====================
    // LISTAR BOOKINGS
    // =====================
    public function list_bookings(WP_REST_Request $request) {
        $auth = $this->auth->validate_request($request);
        if (is_wp_error($auth)) {
            return $this->auth->error_response(
                $auth->get_error_code(),
                $auth->get_error_message(),
                $auth->get_error_data()['status']
            );
        }

        global $wpdb;
        $table_octo = $wpdb->prefix . 'octo_bookings';

        $where  = '1=1';
        $params = array();

        $reseller_ref = $request->get_param('resellerReference');
        if ($reseller_ref) {
            $where   .= ' AND reseller_reference = %s';
            $params[] = $reseller_ref;
        }

        $local_date = $request->get_param('localDate');
        if ($local_date) {
            $where   .= ' AND DATE(utc_created_at) = %s';
            $params[] = $local_date;
        }

        $query = "SELECT * FROM $table_octo WHERE $where ORDER BY utc_created_at DESC LIMIT 50";

        if (!empty($params)) {
            $bookings = $wpdb->get_results($wpdb->prepare($query, ...$params));
        } else {
            $bookings = $wpdb->get_results($query);
        }

        $response = array();
        foreach ($bookings as $booking) {
            $response[] = $this->format_booking($booking);
        }

        return new WP_REST_Response($response, 200);
    }

    // =====================
    // HELPERS
    // =====================
    private function format_booking($booking, $servicio = null) {
        $unit_items = json_decode($booking->unit_items, true) ?? array();
        $contact    = json_decode($booking->contact, true) ?? array();

        // Calcular precio total
        $precio_total = 0;
        if ($servicio) {
            foreach ($unit_items as $item) {
                switch ($item['unitId']) {
                    case 'adult':    $precio_total += floatval($servicio->precio_adulto) * 100;    break;
                    case 'child':    $precio_total += floatval($servicio->precio_nino) * 100;      break;
                    case 'resident': $precio_total += floatval($servicio->precio_residente) * 100; break;
                }
            }
        }

        return array(
            'id'                 => $booking->id,
            'uuid'               => $booking->uuid,
            'testMode'           => (bool) $booking->test_mode,
            'resellerReference'  => $booking->reseller_reference,
            'supplierReference'  => $booking->supplier_reference,
            'status'             => $booking->status,
            'productId'          => $booking->product_id,
            'optionId'           => $booking->option_id,
            'availabilityId'     => $booking->availability_id,
            'contact'            => $contact,
            'unitItems'          => $unit_items,
            'utcCreatedAt'       => $booking->utc_created_at
                ? str_replace(' ', 'T', $booking->utc_created_at) . 'Z'
                : null,
            'utcUpdatedAt'       => $booking->utc_created_at
                ? str_replace(' ', 'T', $booking->utc_created_at) . 'Z'
                : null,
            'utcExpiresAt'       => $booking->utc_expires_at
                ? str_replace(' ', 'T', $booking->utc_expires_at) . 'Z'
                : null,
            'utcConfirmedAt'     => $booking->utc_confirmed_at
                ? str_replace(' ', 'T', $booking->utc_confirmed_at) . 'Z'
                : null,
            'utcCancelledAt'     => $booking->utc_cancelled_at
                ? str_replace(' ', 'T', $booking->utc_cancelled_at) . 'Z'
                : null,
            'pricing'            => array(
                'original'          => intval($precio_total),
                'retail'            => intval($precio_total),
                'net'               => null,
                'currency'          => 'EUR',
                'currencyPrecision' => 2,
            ),
            'cancellation'       => array(
                'refund'    => 'FULL',
                'reason'    => null,
                'utcCancelledAt' => $booking->utc_cancelled_at
                    ? str_replace(' ', 'T', $booking->utc_cancelled_at) . 'Z'
                    : null,
            ),
            'voucher'            => $booking->status === 'CONFIRMED' ? array(
                'redemptionMethod' => 'DIGITAL',
                'utcRedeemedAt'    => null,
                'deliveryOptions'  => array(
                    array(
                        'deliveryFormat' => 'QRCODE',
                        'deliveryValue'  => $booking->supplier_reference,
                    ),
                ),
            ) : null,
        );
    }

    private function generate_uuid() {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    private function decode_availability_id($availability_id) {
        $parts = explode('_', $availability_id);
        if (count($parts) >= 3 && $parts[0] === 'avail') {
            return intval($parts[1]);
        }
        return null;
    }

    private function generate_localizador() {
        global $wpdb;
        $table_config = $wpdb->prefix . 'reservas_configuration';
        $a�0�9o          = date('Y');
        $config_key   = "ultimo_localizador_$a�0�9o";

        $ultimo = $wpdb->get_var($wpdb->prepare(
            "SELECT config_value FROM $table_config WHERE config_key = %s", $config_key
        ));

        $nuevo = $ultimo ? intval($ultimo) + 1 : 1;

        $wpdb->query($wpdb->prepare(
            "INSERT INTO $table_config (config_key, config_value, config_group) VALUES (%s, %s, 'localizadores')
             ON DUPLICATE KEY UPDATE config_value = %s",
            $config_key, $nuevo, $nuevo
        ));

        return str_pad($nuevo, 6, '0', STR_PAD_LEFT);
    }
}